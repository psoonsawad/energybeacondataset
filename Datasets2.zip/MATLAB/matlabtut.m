%gaussian
% INITIALIZE MATLAB



t = -2*pi : pi/100 : 2*pi;
x = cos(t);
y = sin(t);
z = x.^2 + y.^2;
plot (t,x);
xlabel('t')
ylabel('cos(t)')
title('plot of cos function')

subplot(2,2,1);
plot(t,x);
xlabel('t')
ylabel('cos(t)')
title('plot of cos function')
subplot(2,2,2);
plot(t,y)
stem(t,y)
xlabel('t')
ylabel('sin(t)')
title('Stem Plot of Cos Function')
axis([-10 10 -1.5 1.5]);
axis([-0.5 0.5 -1.5 1.5]);
axis([0 0.5 -1.5 1.5]);
plot3(x,y,z)
axis([-1 1 -1 1]);
axis([-1 1 -1 1 -1 1]);
subplot(2,2,4);
plot(t,x,'r','LineWidth',2);
%the color and linewidth can be used to differentiate multiple graphs
%hold command is used to plot multiple functions on the same graph. 
hold
plot(t,y,'g', 'LineWidth',2);
plot(t,z,'y','LineWidth',4);
legend('cos(t)', 'sin(t)','Unit Circle')




