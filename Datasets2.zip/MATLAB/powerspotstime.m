disp('Hello World')
%spot1
t = [9 12 15 18 21];
Pm = [199.95 199.95 199.95 182.61 182.61];
Pl = [74.95 74.95 70.79 58.9 57.12 ];
Pg = [37.48 37.48 35.40 29.45 28.56]
xlabel('Time(hour)');
ylabel('Power(\muW)');
plot(t,Pm,'rx-.')
%[angle,Voc] = titanium;
%f = fit(angle.',Voc.','gauss2');
%plot(f,angle,Voc)
hold on
plot(t,Pl,'ko--')
plot(t,Pg,'bd:')
hold off
%plot(angle,Voc,angle,Isc)
 
title('(a)')
legend('Our solar beacon','luXbeacon','GCell solar beacon')