disp('Hello World')
Voc = [3.91 4.53 4.69 4.74 4.69 4.53 3.91];
Isc = [2.5 11.2 18.2 21.5 18.2 11.2 2.5];
angle = [-90 -60 -30 0 30 60 90];
yyaxis left
xlabel('\theta');
ylabel('Open-circuit Voltage(V)');
plot(angle,Voc,'rx-.')
%[angle,Voc] = titanium;
%f = fit(angle.',Voc.','gauss2');
%plot(f,angle,Voc)
hold on
yyaxis right
ylabel('Short-circuit current (\muA)');
plot(angle,Isc,'ko--')
hold off
%plot(angle,Voc,angle,Isc)
 
title('(a)')
legend('Measurement Voltage','Measurement Current')

