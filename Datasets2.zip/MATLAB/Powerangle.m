Voc = [3.91 4.53 4.69 4.74 4.69 4.53 3.91];
Isc = [2.5 11.2 18.2 21.5 18.2 11.2 2.5];
angle = [-90 -60 -30 0 30 60 90];
%a1 = 1.47;
%b1 = 897.7;
%c1 = 27.08;
%a2 = 0.6994;
%b2 = 810.8;
%c2 = 592.9;

P = Voc .* Isc;
xlabel('\theta');
ylabel('Power(\muW)');
plot(angle,P,'ks-.')
%hold on
%[angle,P] = titanium;
%f = fit(angle.',P.','gauss2');
%for x 
 %f(x) =  a1*exp(-((x-b1)/c1)^2) + a2*exp(-((x-b2)/c2)^2)
%plot(f,angle,P)
%hold off