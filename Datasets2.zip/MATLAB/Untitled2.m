% Create data
b=rand(6)
%Perform Calculation
c=sin(b)
%Subset data
f=c(3,:)

createfigure(f,c)