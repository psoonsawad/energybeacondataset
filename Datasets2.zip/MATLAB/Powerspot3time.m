disp('Hello World')
%spot2
t = [9 12 15 18 21];
Pm = [1951.98 7147.51 3662.17 160.64 93.02];
Pl = [ 761.6 7147.51 1438.14 52.96 26.20];
Pg = [380.8 3573.76 719.07 26.48 13.1];
xlabel('Time(hour)','FontSize',14);
ylabel('Power(\muW)','FontSize',14);
plot(t,Pm,'rx-.')
%[angle,Voc] = titanium;
%f = fit(angle.',Voc.','gauss2');
%plot(f,angle,Voc)
hold on
plot(t,Pl,'ko--')
plot(t,Pg,'bd:')
hold off
%plot(angle,Voc,angle,Isc)
 
title('(c)')
lgd = legend('Our solar beacon','luXbeacon','GCell solar beacon')
lgd.FontSize = 12