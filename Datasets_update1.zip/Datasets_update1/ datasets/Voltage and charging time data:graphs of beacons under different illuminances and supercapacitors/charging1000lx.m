%Filter out beacon with 'D4DC5B68-EBF9-4E41-8BCD-56747023664B' mac address
beacon.b1 = exp1000lx(exp1000lx.mac == 'D4DC5B68-EBF9-4E41-8BCD-56747023664B',:);
beacon.b2 = exp1000lx(exp1000lx.mac == 'C59EED4F-E492-46E3-8F3E-8A55EC9BD08C',:);
beacon.b3 = exp1000lx(exp1000lx.mac == '775DE823-5F28-4A10-B382-C86C0CB9BC8D',:);
beacon.b4 = exp1000lx(exp1000lx.mac == '187393AD-7A3C-47C9-B4DD-E04C8263E290',:);
beacon.b5 = exp1000lx(exp1000lx.mac == '8D7CFBFC-4E01-44A7-83B6-F4420B956168',:);


%=================other mac address====================
% 'C59EED4F-E492-46E3-8F3E-8A55EC9BD08C'
% '775DE823-5F28-4A10-B382-C86C0CB9BC8D'
% '187393AD-7A3C-47C9-B4DD-E04C8263E290'
% '8D7CFBFC-4E01-44A7-83B6-F4420B956168'
%======================================================

%convert the time from string type to date type
beacon.b1.Timestamp = datetime(beacon.b1.Timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b2.Timestamp = datetime(beacon.b2.Timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b3.Timestamp = datetime(beacon.b3.Timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b4.Timestamp = datetime(beacon.b4.Timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b5.Timestamp = datetime(beacon.b5.Timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');

%plot a graph of luxCap verus timestamp

plot(beacon.b1.Timestamp, beacon.b1.luXbeaconCapacitor);
hold on
plot(beacon.b2.Timestamp, beacon.b2.luXbeaconCapacitor);

plot(beacon.b3.Timestamp, beacon.b3.luXbeaconCapacitor);

plot(beacon.b4.Timestamp, beacon.b4.luXbeaconCapacitor);

plot(beacon.b5.Timestamp, beacon.b5.luXbeaconCapacitor);
hold off