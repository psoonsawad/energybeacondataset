%Filter out beacon with 'D4DC5B68-EBF9-4E41-8BCD-56747023664B' mac address
beacon.b1 = exp100lx(exp100lx.mac == 'D4DC5B68-EBF9-4E41-8BCD-56747023664B',:);
beacon.b2 = exp100lx(exp100lx.mac == 'C59EED4F-E492-46E3-8F3E-8A55EC9BD08C',:);
beacon.b3 = exp100lx(exp100lx.mac == '775DE823-5F28-4A10-B382-C86C0CB9BC8D',:);
beacon.b4 = exp100lx(exp100lx.mac == '187393AD-7A3C-47C9-B4DD-E04C8263E290',:);
beacon.b5 = exp100lx(exp100lx.mac == '8D7CFBFC-4E01-44A7-83B6-F4420B956168',:);


%=================other mac address====================
% 'C59EED4F-E492-46E3-8F3E-8A55EC9BD08C'
% '775DE823-5F28-4A10-B382-C86C0CB9BC8D'
% '187393AD-7A3C-47C9-B4DD-E04C8263E290'
% '8D7CFBFC-4E01-44A7-83B6-F4420B956168'
%======================================================

%convert the time from string type to date type
beacon.b1.timestamp = datetime(beacon.b1.timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b2.timestamp = datetime(beacon.b2.timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b3.timestamp = datetime(beacon.b3.timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b4.timestamp = datetime(beacon.b4.timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');
beacon.b5.timestamp = datetime(beacon.b5.timestamp,'InputFormat','yyyy-MM-dd HH:mm:ss.SSS','Format','yyyy-MM-dd HH:mm:ss.SSS');

%plot a graph of luxCap verus timestamp

plot(beacon.b1.timestamp, beacon.b1.luXCap);
hold on
plot(beacon.b2.timestamp, beacon.b2.luXCap);

plot(beacon.b3.timestamp, beacon.b3.luXCap);

plot(beacon.b4.timestamp, beacon.b4.luXCap);

plot(beacon.b5.timestamp, beacon.b5.luXCap);
hold off